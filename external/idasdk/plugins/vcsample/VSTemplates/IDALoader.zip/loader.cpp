#include <idaldr.h>

//--------------------------------------------------------------------------
//
//      check input file format. if recognized, then return 1
//      and fill 'fileformatname'.
//      otherwise return 0
//
static int idaapi accept_file(
	qstring* fileformatname,
	qstring* processor,
	linput_t* li,
	const char*)
{
	return 0;
}

//--------------------------------------------------------------------------
//
//      load file into the database.
//
void idaapi load_file(linput_t* li, ushort /*neflag*/, const char* /*fileformatname*/)
{
}

//----------------------------------------------------------------------
//
//      LOADER DESCRIPTION BLOCK
//
//----------------------------------------------------------------------
loader_t LDSC =
{
	IDP_INTERFACE_VERSION,
	//
	// loader flags
	//
	0,
	//
	//      check input file format. if recognized, then return 1
	//      and fill 'fileformatname'.
	//      otherwise return 0
	//
	accept_file,
	//
	//      load file into the database.
	//
	load_file,
	//
	//      create output file from the database.
	//      this function may be absent.
	//
	nullptr,
	//      take care of a moved segment (fix up relocations, for example)
	nullptr,
	nullptr,
};